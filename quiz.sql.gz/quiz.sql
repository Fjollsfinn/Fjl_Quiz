-- MySQL dump 10.13  Distrib 5.7.19, for Linux (x86_64)
--
-- Host: localhost    Database: quiz
-- ------------------------------------------------------
-- Server version	5.7.19-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `newgame`
--

DROP TABLE IF EXISTS `newgame`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newgame` (
  `Question` varchar(500) DEFAULT NULL,
  `Answer` varchar(500) DEFAULT NULL,
  `IDX` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  UNIQUE KEY `IDX` (`IDX`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newgame`
--

LOCK TABLES `newgame` WRITE;
/*!40000 ALTER TABLE `newgame` DISABLE KEYS */;
INSERT INTO `newgame` VALUES ('How many nitrogen bases can appear in DNA?','4',1),('Denmark\'s Capital is:','Copenhagen',2),('In which year Poland regained independence?','1918',3),('How many years in prison did Nelson Mandela spend?','27',4),('Egypt\'s capital is:','Cairo',5),('What is a name of hereditary lack of blood coagulation ?','hemophilia',6),('What are the names of white blood cells ?','lymphocytes',7),('What is called red dye contained in erythrocytes ?','hemoglobin',8),('Moving part of human skull is:','jaw',9),('The only natural satellite of the Earth is:','Moon',10),('How many planets are in our Solar System ?','8',11),('The largest percentage of air occupies:','nitrogen',12),('What is the name of the green dye found in the plant cells?','chlorophyll',13),('What is smaller: virus or bacteria?','virus',14),('What is the name of the third letter of the Greek alphabet?','gamma',15),('The unit of electric current is?','ampere',16),('Who is the author of three laws of dynamics? (Name and surname)','Isaac Newton',17),('The speed of sound in normal conditions is equal to:  [m/s]','340',18),('Oxidation of oxygen in oxides is:','-2',19),('The name of the first Polish cosmonaut is:','Hermaszewski',20),('What is the color of lacmus in acid solution? ','red',21),('What is the nearest sea to Poland ?','Baltic Sea',22),('What is the name of the first viking on Greenland ? [full name]','Eric the Red',23),('Did Leonardo DiCaprio get an Oscar award ? [y/n]','y',24),('How many stars is on flag of the United States of America ?','50',25);
/*!40000 ALTER TABLE `newgame` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questions` (
  `Question` varchar(500) DEFAULT NULL,
  `Answer` varchar(500) DEFAULT NULL,
  `IDX` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  UNIQUE KEY `IDX` (`IDX`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` VALUES ('How many nitrogen bases can appear in DNA?','4',1),('Denmark\'s Capital is:','Copenhagen',2),('In which year Poland regained independence?','1918',3),('How many years in prison did Nelson Mandela spend?','27',4),('Egypt\'s capital is:','Cairo',5),('What is a name of hereditary lack of blood coagulation ?','hemophilia',6),('What are the names of white blood cells ?','lymphocytes',7),('What is called red dye contained in erythrocytes ?','hemoglobin',8),('Moving part of human skull is:','jaw',9),('The only natural satellite of the Earth is:','Moon',10),('How many planets are in our Solar System ?','8',11),('The largest percentage of air occupies:','nitrogen',12),('What is the name of the green dye found in the plant cells?','chlorophyll',13),('What is smaller: virus or bacteria?','virus',14),('What is the name of the third letter of the Greek alphabet?','gamma',15),('The unit of electric current is?','ampere',16),('Who is the author of three laws of dynamics? (Name and surname)','Isaac Newton',17),('The speed of sound in normal conditions is equal to:  [m/s]','340',18),('Oxidation of oxygen in oxides is:','-2',19),('The name of the first Polish cosmonaut is:','Hermaszewski',20),('What is the color of lacmus in acid solution? ','red',21),('What is the nearest sea to Poland ?','Baltic Sea',22),('What is the name of the first viking on Greenland ? [full name]','Eric the Red',23),('Did Leonardo DiCaprio get an Oscar award ? [y/n]','y',25),('How many stars is on flag of the United States of America ?','50',26);
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scores`
--

DROP TABLE IF EXISTS `scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scores` (
  `Name` varchar(20) DEFAULT NULL,
  `Score` int(11) DEFAULT NULL,
  `IDX` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  UNIQUE KEY `IDX` (`IDX`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scores`
--

LOCK TABLES `scores` WRITE;
/*!40000 ALTER TABLE `scores` DISABLE KEYS */;
INSERT INTO `scores` VALUES ('MAKA PAKA',48,1),('Thindur',40,2),('h',-20,3),('d',-20,4),('dfdf',-20,5),('d',-20,6),('1234',-20,7),('00',-20,8),('99',-20,9),('88',-20,10),('dsdasdas',-20,11),('fff',-20,12),('ja',-16,13);
/*!40000 ALTER TABLE `scores` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-13 18:52:07
